package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private Map<Long, String> userDb = new HashMap<>();

    // GET all users
    @GetMapping
    public List<String> getAllUsers() {
        return new ArrayList<>(userDb.values());
    }

    // GET user by ID
    @GetMapping("/{id}")
    public String getUser(@PathVariable Long id) {
        return userDb.getOrDefault(id, "User not found");
    }

    // POST new user
    @PostMapping
    public String createUser(@RequestParam Long id, @RequestParam String name) {
        userDb.put(id, name);
        return "User created: " + name;
    }

    // PUT update user
    @PutMapping("/{id}")
    public String updateUser(@PathVariable Long id, @RequestParam String name) {
        if (userDb.containsKey(id)) {
            userDb.put(id, name);
            return "User updated: " + name;
        } else {
            return "User not found";
        }
    }

    // DELETE user
    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable Long id) {
        if (userDb.containsKey(id)) {
            userDb.remove(id);
            return "User deleted";
        } else {
            return "User not found";
        }
    }
}
