package com.example.demo.utils;

import com.itextpdf.kernel.pdf.*;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.font.PdfEncodings;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Cell;

public class PDFUtils {

    public static void main(String[] args) throws Exception {
        String dest = "fast_million_rows.pdf";
        String fontPath = "src/main/resources/fonts/TIMES.TTF";
        PdfFontFactory.register(fontPath, "TimesNew");
        PdfFont font = PdfFontFactory.createFont(StandardFonts.TIMES_ROMAN);
        font = PdfFontFactory.createRegisteredFont("TimesNew", PdfEncodings.IDENTITY_H);
        PdfWriter writer = new PdfWriter(dest);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);
        document.setFont(font);
        long st = System.currentTimeMillis();
        int numColumns = 5;
        long totalRows = 1000_00;
        int rowsPerPage = 10;  // Keep table manageable per page

        Table table = new Table(numColumns);
        // Add header
        for (int i = 1; i <= numColumns; i++) {
            table.addHeaderCell("Cột " + i);
        }

        for (long i = 1; i <= totalRows; i++) {
//            for (int col = 1; col <= numColumns; col++) {
                table.addCell("Số " +i );
                table.addCell("Tên tiếng Việt" + i);
                table.addCell("Row Tiếng Việt Nam Khoẳng khắc không làm sao" + i);
//                Cell cell = new Cell().add(new Paragraph("Row " + col)).setKeepTogether(true);
//                table.addCell(cell);
                table.addCell("Dòng mô tả rất dài có thể nhiều dòng nhiều dòng nữa..." + i);
                table.addCell("Dòng mô tả rất dài có thể nhiều dòng nhiều dòng nữa..." + i);
//            }
            // Flush table every rowsPerPage rows
//            if (i % rowsPerPage == 0) {
//                document.add(table);
//                document.add(new Paragraph(" ")); // add some spacing between tables/pages
//                table = new Table(numColumns);
//                for (int h = 1; h <= numColumns; h++) {
//                    table.addHeaderCell("Header " + h);
//                }
//            }
        }
        document.add(table);
        long t = System.currentTimeMillis();
        System.out.println("Preparing: " + (t-st));

        // Add remaining rows
        if (totalRows % rowsPerPage != 0) {
            document.add(table);
        }
        long t2 = System.currentTimeMillis();
        System.out.println("Add table: " + (t2-t));
        document.close();
        System.out.println("Close: " + (System.currentTimeMillis() - t2));
        System.out.println("PDF generated with " + totalRows + " rows");
    }
}
